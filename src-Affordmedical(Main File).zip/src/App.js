import React, { useState } from 'react';
import StockForm from './components/StockForm';
import ResultDisplay from './components/ResultDisplay';
import './App.css';

function App() {
  const [result, setResult] = useState(null);

  return (
    <div className="App">
      <StockForm onResult={setResult} />
      {result && <ResultDisplay result={result} />}
    </div>
  );
}

export default App;
