import React from 'react';

function ResultDisplay({ result }) {
  if (!result) return null;

  if (result.error) {
    return (
      <div className="result" style={{ color: 'red', marginTop: '20px' }}>
        <h3>Error:</h3>
        <p>{result.error}</p>
      </div>
    );
  }

  // Display average price result
  if (result.averagePrice !== undefined) {
    return (
      <div className="result" style={{ marginTop: '20px', backgroundColor: '#f5f5f5', padding: '10px', borderRadius: '8px' }}>
        <h3>Average Price Result</h3>
        <p><strong>Ticker:</strong> {result.ticker}</p>
        <p><strong>Minutes:</strong> {result.minutes}</p>
        <p><strong>Average Price:</strong> ${result.averagePrice.toFixed(2)}</p>
      </div>
    );
  }

  // Display correlation result
  if (result.correlation !== undefined) {
    return (
      <div className="result" style={{ marginTop: '20px', backgroundColor: '#f5f5f5', padding: '10px', borderRadius: '8px' }}>
        <h3>Correlation Result</h3>
        <p><strong>Ticker 1:</strong> {result.ticker1}</p>
        <p><strong>Ticker 2:</strong> {result.ticker2}</p>
        <p><strong>Minutes:</strong> {result.minutes}</p>
        <p><strong>Correlation:</strong> {result.correlation.toFixed(4)}</p>
        <p>
          <em>{result.correlation > 0.7 ? 'Strong Positive Correlation' : result.correlation < -0.7 ? 'Strong Negative Correlation' : 'Weak/No Correlation'}</em>
        </p>
      </div>
    );
  }

  // Fallback: if none of the above matches, just stringify result
  return (
    <div className="result" style={{ whiteSpace: 'pre-wrap', backgroundColor: '#f5f5f5', padding: '10px', marginTop: '20px' }}>
      <h3>Result:</h3>
      <pre>{JSON.stringify(result, null, 2)}</pre>
    </div>
  );
}

export default ResultDisplay;
