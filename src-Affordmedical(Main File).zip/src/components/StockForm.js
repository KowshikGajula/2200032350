import React, { useState } from 'react';
import './StockForm.css';

function StockForm({ onResult }) {
  const [ticker1, setTicker1] = useState('');
  const [ticker2, setTicker2] = useState('');
  const [minutes, setMinutes] = useState('');
  const [mode, setMode] = useState('average');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (isNaN(minutes) || minutes <= 0) {
      onResult({ error: 'Minutes must be a positive number' });
      return;
    }

    const baseURL = 'http://20.244.56.144/evaluation-service';

    let url = '';
    if (mode === 'average') {
      url = `${baseURL}/stocks/${ticker1}?minutes=${minutes}&aggregation=average`;
    } else {
      url = `${baseURL}/correlation/${ticker1}/${ticker2}?minutes=${minutes}`;
    }

    try {
      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`Server error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      onResult(data);
    } catch (error) {
      onResult({ error: error.message || 'Error fetching data' });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="form">
      <h2>Stock Aggregation Service</h2>
      <label>
        Ticker 1:
        <input
          type="text"
          value={ticker1}
          onChange={e => setTicker1(e.target.value.toUpperCase())}
          required
        />
      </label>

      {mode === 'correlation' && (
        <label>
          Ticker 2:
          <input
            type="text"
            value={ticker2}
            onChange={e => setTicker2(e.target.value.toUpperCase())}
            required
          />
        </label>
      )}

      <label>
        Minutes:
        <input
          type="number"
          min="1"
          value={minutes}
          onChange={e => setMinutes(e.target.value)}
          required
        />
      </label>

      <label>
        Mode:
        <select value={mode} onChange={e => setMode(e.target.value)}>
          <option value="average">Average Price</option>
          <option value="correlation">Correlation</option>
        </select>
      </label>

      <button type="submit">Submit</button>
    </form>
  );
}

export default StockForm;
